const Movie = require('../models/movie');
const BadRequestError = require('../errors/bad-req-err');
const ServerError = require('../errors/serv-err');
const NotFoundError = require('../errors/not-found-err');
const ForbiddenError = require('../errors/forbidden-err');

const getMovies = (req, res) => Movie.find({})
  .then((movies) => res.status(200).send(movies))
  .catch((err) => res.status(500).send(err));

const createMovie = (req, res, next) => {
  const {
    // eslint-disable-next-line max-len
    country, director, duration, year, description, image, trailer, nameRU, nameEN, thumbnail, movieId,
  } = req.body;
  console.log(req.body);
  const owner = req.user._id;
  Movie.create({
    // eslint-disable-next-line max-len
    country, director, duration, year, description, image, trailer, nameRU, nameEN, thumbnail, owner, movieId,
  })
    /* .then((movie) => {
      res.status(200).send(movie);
    }) */
    .then((movie) => res.status(201).send({
      data: {
        movieId: movie.id,
        country: movie.country,
        director: movie.director,
        duration: movie.duration,
        year: movie.year,
        description: movie.description,
        image: movie.image,
        trailer: movie.trailer,
        thumbnail: movie.thumbnail,
        nameRU: movie.nameRU,
        nameEN: movie.nameEN,
      },
    }))
    .catch((err) => {
      if (err) {
        throw new BadRequestError({ message: `Введены некорректные данные: ${err}` });
      } else {
        throw new ServerError({ message: `Внутренняя ошибка сервера: ${err}` });
      }
    })
    .catch(next);
};

const deleteMovie = (req, res, next) => {
  console.log(req.params.id);
  Movie.findById(req.params.id)
    .then((movie) => {
      if (!movie) {
        throw new NotFoundError('Нет карточки с таким id');
      }
      if (movie.owner.toString() !== req.user._id.toString()) { // не работает
        throw new ForbiddenError('Нет прав на удаление карточки'); // не работает
      } else {
        Movie.findByIdAndDelete(req.params.id)
          // eslint-disable-next-line no-shadow
          .then((movie) => {
            res.status(200).send(movie);
          })
          .catch(next);
      }
    })
    .catch(next);
};

module.exports = {
  getMovies, createMovie, deleteMovie,
};
