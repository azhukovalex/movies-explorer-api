const usersRouter = require('express').Router();
const {
  updateUser, getCurrentUser,
} = require('../controllers/users');

usersRouter.get('/users/me', getCurrentUser);
usersRouter.patch('/users/me', updateUser);

module.exports = usersRouter;

/* # возвращает информацию о пользователе (email и имя)
GET /users/me

# обновляет информацию о пользователе (email и имя)
PATCH /users/me */
